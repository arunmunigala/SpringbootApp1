package com.orders.my;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersApisApplicationTests {

	@Test
	void contextLoads() {
	}

}
