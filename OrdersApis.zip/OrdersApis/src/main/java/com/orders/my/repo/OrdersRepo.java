package com.orders.my.repo;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.orders.my.entity.OrdersEntity;

@Repository
@Transactional
public interface OrdersRepo extends CrudRepository<OrdersEntity, String>{
	
	@Query(value = "SELECT " + 
			"  * " + 
			"FROM " + 
			"  TEMP_ARUN " + 
			"LEFT JOIN ( " + 
			"  SELECT " + 
			"    TEMP_ARUN.POST_ID, count(TEMP_ARUN.POST_ID) as count " + 
			"  FROM " + 
			"    TEMP_ARUN " + 
			"  GROUP BY " + 
			"    TEMP_ARUN.POST_ID " + 
			") counter ON counter.POST_ID = TEMP_ARUN.POST_ID " + 
			"ORDER BY " + 
			"  counter.count DESC", nativeQuery = true)
	List<OrdersEntity> findByMaxComments();
	List<OrdersEntity> findByPostId(String postId);
	List<OrdersEntity> findByEmail(String email);
	List<OrdersEntity> findByName(String name);
	List<OrdersEntity> findByBody(String body);
	
	
}
