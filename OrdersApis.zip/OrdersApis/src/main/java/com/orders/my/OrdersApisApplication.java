package com.orders.my;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;


@SpringBootApplication
public class OrdersApisApplication extends SpringBootServletInitializer {

	// Start for external server deployment
		@Override
		protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {

			return application.profiles(System.getProperty("test.env")).sources(OrdersApisApplication.class);
		}
		// End for external server deployment

		public static void main(String[] args) {

			SpringApplication app = new SpringApplication(OrdersApisApplication.class);
			app.setAdditionalProfiles("dev");
			app.run();
		}
}
