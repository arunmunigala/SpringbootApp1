package com.orders.my.main;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.orders.my.entity.OrdersEntity;
import com.orders.my.repo.OrdersRepo;

/** 
 * PROGRAMMER: Arun Munigala
 * CHANGE-NO: 
 * TASK-NO: 
 * DATE CREATED: Sep ,2020
 * TAG AS: 
 * REASON(S): Orders
 * MODIFICATION: 
 */




@RestController
public class CommentsMainClass {
	private static final Logger logger = LoggerFactory.getLogger(CommentsMainClass.class);
	private static Class className = CommentsMainClass.class;
	Predicate<Object> p = input -> input!=null;
	
	@Autowired
	OrdersRepo	 OrdersRepository;
	
	@PostMapping(value = "/getAllPostsByComments")
	public ResponseEntity<List<OrdersEntity>> getAllPostsOrderbyComments() {
		
		List<OrdersEntity> goalDetails = new ArrayList<OrdersEntity>();
		try {
			goalDetails = OrdersRepository.findByMaxComments();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return new ResponseEntity<List<OrdersEntity>> (goalDetails, HttpStatus.OK);
	}
	@PostMapping(value = "/getDetails")
	public ResponseEntity<List<OrdersEntity>> getAllPostsOrderbyComments(String post_id) {
		
		List<OrdersEntity> goalDetails = new ArrayList<OrdersEntity>();
		try {
			goalDetails = OrdersRepository.findByPostId(post_id);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return new ResponseEntity<List<OrdersEntity>> (goalDetails, HttpStatus.OK);
	}
	
	@PostMapping(value = "/search")
	public ResponseEntity<List<OrdersEntity>> search(String fieldName, String value) {
		
		List<OrdersEntity> goalDetails = new ArrayList<OrdersEntity>();
		try {
			if("post_id".equals(fieldName)) {
				goalDetails = OrdersRepository.findByPostId(value);
			}else if("name".equals(fieldName)) {
				goalDetails = OrdersRepository.findByName(value);
			}else if("email".equals(fieldName)) {
				goalDetails = OrdersRepository.findByEmail(value);
			}else {
				goalDetails = OrdersRepository.findByBody(value);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return new ResponseEntity<List<OrdersEntity>> (goalDetails, HttpStatus.OK);
	}
	
}
