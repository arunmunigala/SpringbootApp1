package com.orders.my.pojo;

import lombok.Data;

@Data
public class OrderPojo {

}
